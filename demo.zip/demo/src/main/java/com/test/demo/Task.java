package com.test.demo;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Task {

	private Integer taskId;
	private String title;
	private String description;
	private Boolean completed;
	private Date createDate;
	private Date completedDate;

	public Integer getTaskId() {
		return taskId;
	}

	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getCompleted() {
		return completed;
	}

	public void setCompleted(Boolean completed) {
		this.completed = completed;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getCompletedDate() {
		return completedDate;
	}

	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}

	@JsonCreator
	public Task(@JsonProperty("taskId") Integer taskId, 
			@JsonProperty("title") String title, 
			@JsonProperty("description") String description, 
			@JsonProperty("completed") Boolean completed, 
			@JsonProperty("createDate")Date createDate,
			@JsonProperty("completedDate") Date completedDate) {
		super();
		this.taskId = taskId;
		this.title = title;
		this.description = description;
		this.completed = completed;
		this.createDate = createDate;
		this.completedDate = completedDate;
	}

	public Task() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Task [taskId=" + taskId + ", title=" + title + ", description=" + description + ", completed="
				+ completed + ", createDate=" + createDate + ", completedDate=" + completedDate + "]";
	}

}
