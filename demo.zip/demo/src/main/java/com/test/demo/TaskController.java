package com.test.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.websocket.server.PathParam;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/")
public class TaskController {

	public static Map<Integer, Task> taskData = new HashMap<>();

	@PostMapping(value = "/tasks", consumes = "application/json")
	public String createTask(@RequestBody Task taskInfo) {

		try {
			System.out.println("CREATE Task -- START");
			if (taskInfo != null) {
				if (taskData.containsKey(taskInfo.getTaskId()))
					return "Task already existed";
				else {
					if (taskInfo.getTaskId() != null && taskInfo.getTaskId() > 0) {
						taskData.put(taskInfo.getTaskId(), taskInfo);
						return "Task created successfully";
					} else {
						return "Invalid TaskId";
					}
				}
			} else {
				return "Invalid TaskData";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "Failed to create a Task";
		} finally {
			System.out.println("CREATE Task -- END");
		}
	}

	@GetMapping(value = "/tasks", produces = "application/json")
	public Object getTasks() {
		try {
			System.out.println("GET Tasks -- START");
			List<Task> taskList = new ArrayList<>();
			for (Entry<Integer, Task> data : taskData.entrySet()) {
				taskList.add(data.getValue());
			}
			return taskList;
		} catch (Exception e) {
			e.printStackTrace();
			return "Failed to Found tasks";
		} finally {
			System.out.println("GET Tasks -- END");
		}
	}

	@GetMapping(value = "/tasks/{taskId}", produces = "application/json")
	public Object getTaskById(@PathVariable Integer taskId) {
		try {
			System.out.println("GET Task -- START");
			if (taskData.containsKey(taskId)) {
				return taskData.get(taskId);
			} else {
				return "TaskId Not Found";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "Failed to Found task";
		} finally {
			System.out.println("GET Task -- END");
		}
	}

	@PutMapping(value = "/tasks/{taskId}", consumes = "application/json")
	public String updateTaskById(@PathVariable Integer taskId, @RequestBody Task taskInfo) {
		try {
			System.out.println("UPDATE Task -- START");
			if (taskData.containsKey(taskId)) {
				taskInfo.setTaskId(taskId);
				taskData.replace(taskId, taskInfo);
				return "Updated Task Successfully";
			} else {
				return "TaskId Not Found";
			}
		} catch (Exception e) {
			return "Failed to Update the Task";
		} finally {
			System.out.println("UPDATE Task -- END");
		}
	}
}
